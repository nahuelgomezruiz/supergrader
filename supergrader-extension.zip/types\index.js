// Central type definitions for SuperGrader
export {};
//# sourceMappingURL=index.js.map